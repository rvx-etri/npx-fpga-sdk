// ****************************************************************************
// ****************************************************************************
// Copyright SoC Design Research Group, All rights reservxd.
// Electronics and Telecommunications Research Institute (ETRI)
// 
// THESE DOCUMENTS CONTAIN CONFIDENTIAL INFORMATION AND KNOWLEDGE
// WHICH IS THE PROPERTY OF ETRI. NO PART OF THIS PUBLICATION IS
// TO BE USED FOR ANY OTHER PURPOSE, AND THESE ARE NOT TO BE
// REPRODUCED, COPIED, DISCLOSED, TRANSMITTED, STORED IN A RETRIEVAL
// SYSTEM OR TRANSLATED INTO ANY OTHER HUMAN OR COMPUTER LANGUAGE,
// IN ANY FORM, BY ANY MEANS, IN WHOLE OR IN PART, WITHOUT THE
// COMPLETE PRIOR WRITTEN PERMISSION OF ETRI.
// ****************************************************************************
// 2026-07-13
// Kyuseung Han (han@etri.re.kr)
// ****************************************************************************
// ****************************************************************************

`include "ervp_global.vh"




module RVX_MODULE_061
(
	rvx_port_3,
	rvx_port_6,
	rvx_port_1,
	rvx_port_2,
	rvx_port_4,
	rvx_port_0,
	rvx_port_5
);




parameter RVX_GPARA_0 = 4;
parameter RVX_GPARA_1 = RVX_GPARA_0+1;

input wire rvx_port_3, rvx_port_6;
output wire rvx_port_1;
output wire [RVX_GPARA_0-1:0] rvx_port_2;
input wire rvx_port_4;

input wire [RVX_GPARA_1-1:0] rvx_port_0;
output wire rvx_port_5;

RVX_MODULE_129
#(
	.RVX_GPARA_0(RVX_GPARA_0),
	.RVX_GPARA_1(RVX_GPARA_1),
	.RVX_GPARA_2(0)
)
i_rvx_instance_0
(
	.rvx_port_6(rvx_port_3),
	.rvx_port_7(rvx_port_6),
	.rvx_port_0(rvx_port_1),
	.rvx_port_2(rvx_port_2),
	.rvx_port_5(rvx_port_4),
	.rvx_port_3(1'b 0),
	.rvx_port_1(rvx_port_0),
	.rvx_port_4(rvx_port_5)
);

endmodule

